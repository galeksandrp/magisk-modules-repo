# OnePlus 9 & 9 Pro Camera Unlocker

## Information
This module systemless-ly replaces an existing library with a modified one file which unlocks face detection

## Links
- [GitHub](https://github.com/Magisk-Modules-Alt-Repo/oneplus-9-9pro-camera-unlocker)
- [MMT-Ex](https://github.com/Zackptg5/MMT-Extended)

## Credits
- AnierinB
- Cartesian8445
- JeusChrit
- Luk1377
