#!/system/bin/sh

ui_print " "
ui_print " Sony Music Player"
ui_print " "
ui_print "By Manish4586 @xda"
ui_print " "

DEVICE=`getprop ro.product.device`

ui_print "Device: "$DEVICE""
ui_print " "

 ui_print "Installing for "$DEVICE" ..."

