# Static Tcpdump for AARCH64 devices.
### (C) S-trace @ [forum.4pda.ru](https://4pda.ru/forum/index.php?showuser=1718487)

## Description:
This module adds a static AARCH64 Tcpdump binary for capturing network packets from the device's network interfaces to .pcap files.
If you don't know what is Tcpdump - you probably don't want to install this module.
This binary was built in LineageOS 16.0 tree.

[Official Tcpdump's site](https://www.tcpdump.org/)

## Requirements:
 - Magisk
 - root
 
## Support:
 - [QMS private messages at forum.4pda.ru](https://4pda.ru/forum/index.php?act=qms&mid=1718487)

## Donate and support my work:
 - [PayPal](S-trace@list.ru)
 - [YandexMoney](https://money.yandex.ru/to/410013541261449)
