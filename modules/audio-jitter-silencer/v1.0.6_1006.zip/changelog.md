## Change logs

# v1.0.6
* Added Punch hole cutout to the doze white-list

# v1.0.5
* Tuned the doze whitelist for audio

# v1.0.4
* Changed to set battery optimizations to be disabled without fail

# v1.0.3
* Disabled the adaptive battery charging feature (esp. on Tensor devices)
* Added some apps into the doze white-list

# v1.0.0
* Initial Release

##
