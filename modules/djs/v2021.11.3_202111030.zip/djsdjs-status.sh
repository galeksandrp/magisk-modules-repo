#!/system/bin/sh
pgrep -f /djs.sh
exit $?
