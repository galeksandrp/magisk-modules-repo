#!/system/bin/sh
exec 2>/dev/null
rm -rf /data/adb/vr25/fbind-data
rmdir /data/adb/vr25
exit 0
