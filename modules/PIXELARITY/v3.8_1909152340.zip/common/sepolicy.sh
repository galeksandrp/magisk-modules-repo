"create system_server sdcardfs file" "allow system_server sdcardfs file { write }"
