# charch_openrc
Initialize OpenRC for the default ChArch rootfs instance.
