# ThemedProject
![latest release badge](https://img.shields.io/github/v/release/Osanosa/ThemedProject?sort=semver)
![total-download-count](https://img.shields.io/github/downloads/Osanosa/ThemedProject/total?color=brightgreen)

A8+, Magisk needed

<p align="center">
<img src="https://user-images.githubusercontent.com/80209416/224477121-546d3b72-6da4-48b3-a3bf-1147beeb04a0.jpg" width="130" />
<img src="https://user-images.githubusercontent.com/80209416/224477119-fb14d617-ad3c-47ed-9ab8-94753ce88d9e.jpg" width="130" />
<img src="https://user-images.githubusercontent.com/80209416/224477118-2e0324bc-d5f6-4dc4-bce3-7ccbe8308666.jpg" width="130" />
<img src="https://user-images.githubusercontent.com/80209416/224477117-8c917b6d-ab17-4260-8dd5-2eb71f948da2.jpg" width="130" />
<img src="https://user-images.githubusercontent.com/80209416/224477116-cfc46439-332e-4a2e-afda-97889d301872.jpg" width="130" />
<img src="https://user-images.githubusercontent.com/80209416/224477115-1786d40e-67eb-4747-ae0c-133ae9878c31.jpg" width="130" />
<img src="https://user-images.githubusercontent.com/80209416/224477125-6d3be706-dbdb-4438-8d3a-144feac7f39d.jpg" width="130" />
<img src="https://user-images.githubusercontent.com/80209416/224477124-9ff39c65-7cb6-4949-a489-31f57f6145db.jpg" width="130" />
<img src="https://user-images.githubusercontent.com/80209416/224477123-8bdae593-d614-4403-bc99-7256b6f3979b.jpg" width="130" />


</p>
