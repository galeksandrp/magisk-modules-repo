#!/system/bin/sh
MODDIR ${0%/*}

# @modulostk [telegram]
#####################################
#Small battery
resetprop -n ro.config.small_battery true