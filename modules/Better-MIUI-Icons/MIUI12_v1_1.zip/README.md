
# This module no longer works on the latest versions of MIUI.
The version last tested on was EU 20.7.9. This repository is now archived.


![banner](banner.png)

This module systemlessly installs more modern icons to /system/media/theme/miui_mod_icons.\
The icons will be shown in the app info screen, recent apps, and stock launcher.


[Download here](https://github.com/Magisk-Modules-Alt-Repo/Better-MIUI-Icons/releases)


# Disclaimer
These icons were extracted from the MiRoom ROM project, which has unfortunately shut down.
\
Only the code is licensed under GPLv3. All image assets are property of the MiRoom developers.

