## TWRP A/B Retention Script
### osm0sis @ xda-developers
*Keep TWRP installed after an A/B OTA*

### Links
* [GitHub](https://github.com/Magisk-Modules-Repo/twrp-keep)
* [Support](https://is.gd/osm0_)
* [Sponsor](https://github.com/sponsors/osm0sis)
* [Donate](https://www.paypal.me/osm0sis)

### Description
**This is NOT a normal module - it will NOT install any actual files.**

Flash this script zip after each OTA has installed, but before you install Magisk to Inactive Slot from the Magisk app.

Initial zip install should be manually via "Install from storage" in the Magisk app. It will then show in the Magisk app's installed modules list but with a fake update always pending to allow downloading future actual updates and/or flashing as needed.
