## Reset sensitive props

Reset sensitive properties to safe state, take from MagiskHide code