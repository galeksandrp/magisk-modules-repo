
pre_install() {
    # Do something here 
    return 0
}
