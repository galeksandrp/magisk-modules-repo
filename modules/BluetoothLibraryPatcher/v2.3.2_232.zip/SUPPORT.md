## Library not supported

If you are here so your bluetooth library isn't supported by the module yet.

Open an issue here in [github](https://github.com/Magisk-Modules-Repo/BluetoothLibraryPatcher/issues/new) or at the [XDA thread](https://forum.xda-developers.com/galaxy-note-9/development/zip-libbluetooth-patcher-fix-losing-t4017735).

A file called BluetoothLibPatcher-files.tar has been created on the main folder of your phone storage.
Please attach it (or a link to it) with your report!
