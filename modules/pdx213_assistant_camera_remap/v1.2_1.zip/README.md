# Xperia 10 III Google Assistant Button Remapper

Remaps the Google Assistant button as a camera button

Magisk 20.4+
