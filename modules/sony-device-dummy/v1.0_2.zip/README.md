# Sony Device Dummy

**You must clear Google Play Store's data in Settings in order to install Sony apps via Google Play!**

This module only add the libraries what all sony xperia apps dependence on. Remember that not **All** apps can be used or installed. Some of them need privileged permission or some need platform signature.

After clear your Google Play Store's user data, you can find all available xperia apps and install them.
