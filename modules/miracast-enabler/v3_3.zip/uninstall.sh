
# Disable WiFi Display mode
setprop persist.debug.wfd.enable 0
