# One UI Sounds [![HitCount](http://hits.dwyl.io/Magisk-Modules-Repo/One-UI-Sounds.svg)](http://hits.dwyl.io/Magisk-Modules-Repo/One-UI-Sounds)

This module copies One UI's system sounds (notifications, rigtones and UI sounds) to `/system/media/audio`; files taken from the Galaxy S10+ stock ROM (G975FXXU2ASF3) based on One UI 1.1. Some UI sounds may not be replaced if your ROM has different filenames.

# Changelog
## v1.1
- Added a missing UI sound
## v1.0
- Initial release
