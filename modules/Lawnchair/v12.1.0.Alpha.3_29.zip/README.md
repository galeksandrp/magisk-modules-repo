# Lawnchair

**Summary**: This repo contains: Lawnchair assets ([lawnchair](https://lawnchair.app)):

- Launcher

- Lawn icons

- Feeds integration

- Recents provider

it's simply a magisk module to system-ize them. 


## Credits
- **Lawnchair team** for their awesome work.

## Download
get latest build directly from <a href="https://github.com/Magisk-Modules-Alt-Repo/Lawnchair/releases/latest">here</a>
