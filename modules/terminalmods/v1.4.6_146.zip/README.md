# Terminal Modifications

## Archived

Repo has been moved to [skittles9823/terminalmods](https://github.com/skittles9823/terminalmods)
