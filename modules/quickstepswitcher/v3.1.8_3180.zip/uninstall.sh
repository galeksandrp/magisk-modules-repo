./$(dirname $0)/quickswitch --uninstall
