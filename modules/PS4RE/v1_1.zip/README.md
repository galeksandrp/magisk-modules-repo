# PS4 Remote Play Enabler
A Magisk module enables install and use PS4 Remote Play from PlayStore for non-Sony devices. 

# Note
If dont appear avalible for install please clear data in PlayStore App and is necessary add PS4 Remote app to Magisk Hide.

# Changelog

### V 1.0

Initial release

# Credits
- [eric9401](http://forum.xda-developers.com/android/apps-games/5-0-playstation-remote-play-android-t3466339) Initial stuff;
- [Seyaru](http://forum.xda-developers.com/donatetome.php?u=1917665) This module;
